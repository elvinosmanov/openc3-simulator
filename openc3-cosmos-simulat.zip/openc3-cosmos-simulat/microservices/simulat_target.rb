#!/usr/bin/env ruby
# encoding: ascii-8bit

require 'openc3'
require 'openc3/interfaces/simulated_target_interface'
require 'openc3/utilities/simulated_target'

module OpenC3
  class SimulatTarget < SimulatedTarget
    def initialize(filename)
      super(filename)
      
      # Initialize STATUS packet
      packet = @tlm_packets['SIMULAT2']['STATUS']
      packet.write('TEMP1', 0.0)
      packet.write('TEMP2', 10.0) 
      packet.write('TEMP3', 20.0)
      packet.write('TEMP4', -10.0)
      packet.enable_method(:read_temp1)
      packet.enable_method(:read_temp2)
      packet.enable_method(:read_temp3)
      packet.enable_method(:read_temp4)
      packet.enable_method(:write_heater)
      
      # Initialize POWER packet
      power_packet = @tlm_packets['SIMULAT2']['POWER']
      power_packet.write('HEATER_POWER', 0)
      power_packet.write('RADIO_POWER', 1)
      power_packet.write('CAMERA_POWER', 0)
      power_packet.write('BATTERY_VOLTAGE', 12.5)
      power_packet.write('BATTERY_CURRENT', 2.1)
      power_packet.write('SOLAR_PANEL_VOLTAGE', 14.2)
      power_packet.write('POWER_CONSUMPTION', 25.0)
      power_packet.enable_method(:update_power_data)
      
      # Initialize ENVIRONMENT packet
      env_packet = @tlm_packets['SIMULAT2']['ENVIRONMENT']
      env_packet.write('PRESSURE', 101325.0)
      env_packet.write('HUMIDITY', 45.0)
      env_packet.write('RADIATION', 0.1)
      env_packet.write('MAGNETIC_FIELD_X', 0.000025)
      env_packet.write('MAGNETIC_FIELD_Y', 0.000030)
      env_packet.write('MAGNETIC_FIELD_Z', 0.000045)
      env_packet.write('ACCELEROMETER_X', 0.0)
      env_packet.write('ACCELEROMETER_Y', 0.0)
      env_packet.write('ACCELEROMETER_Z', -9.81)
      env_packet.enable_method(:update_environment_data)
      
      # System state variables
      @current_mode = 1  # NORMAL mode
      @mode_duration = 0
    end

    def set_rates
      # Telemetry rates are set in the interface class (sim_simulat.rb)
      # This method is called by the simulated target framework
      super
    end

    def write(packet)
      name = packet.packet_name.upcase
      case name
      when 'COLLECT'
        OpenC3::Logger.info("SimulatTarget: Received COLLECT command")
        ack_packet = @tlm_packets['SIMULAT2']['HEALTH_STATUS']
        ack_packet.write('COLLECTS', ack_packet.read('COLLECTS') + 1)
        
      when 'CLEAR'
        OpenC3::Logger.info("SimulatTarget: Received CLEAR command")
        ack_packet = @tlm_packets['SIMULAT2']['HEALTH_STATUS']
        ack_packet.write('COLLECTS', 0)
        
      when 'SETPARAMS'
        value1 = packet.read('VALUE1')
        value2 = packet.read('VALUE2')
        value3 = packet.read('VALUE3')
        OpenC3::Logger.info("SimulatTarget: Received SETPARAMS - V1:#{value1}, V2:#{value2}, V3:#{value3}")
        ack_packet = @tlm_packets['SIMULAT2']['PARAMS']
        ack_packet.write('VALUE1', value1)
        ack_packet.write('VALUE2', value2)
        ack_packet.write('VALUE3', value3)
        ack_packet.write('VALUE4', 0.0)  # Default values
        ack_packet.write('VALUE5', 0.0)
        
      # Power control commands
      when 'HEATER_ON'
        OpenC3::Logger.info("SimulatTarget: Heater ON")
        @tlm_packets['SIMULAT2']['POWER'].write('HEATER_POWER', 1)
        
      when 'HEATER_OFF'
        OpenC3::Logger.info("SimulatTarget: Heater OFF")
        @tlm_packets['SIMULAT2']['POWER'].write('HEATER_POWER', 0)
        
      when 'RADIO_ON'
        OpenC3::Logger.info("SimulatTarget: Radio ON")
        @tlm_packets['SIMULAT2']['POWER'].write('RADIO_POWER', 1)
        
      when 'RADIO_OFF'
        OpenC3::Logger.info("SimulatTarget: Radio OFF")
        @tlm_packets['SIMULAT2']['POWER'].write('RADIO_POWER', 0)
        
      when 'CAMERA_ON'
        OpenC3::Logger.info("SimulatTarget: Camera ON")
        @tlm_packets['SIMULAT2']['POWER'].write('CAMERA_POWER', 1)
        
      when 'CAMERA_OFF'
        OpenC3::Logger.info("SimulatTarget: Camera OFF")
        @tlm_packets['SIMULAT2']['POWER'].write('CAMERA_POWER', 0)
        
      # Mode control commands
      when 'SAFE_MODE'
        OpenC3::Logger.info("SimulatTarget: Setting SAFE mode")
        @current_mode = 0
        
      when 'NORMAL_MODE'
        OpenC3::Logger.info("SimulatTarget: Setting NORMAL mode")
        @current_mode = 1
        
      when 'SCIENCE_MODE'
        OpenC3::Logger.info("SimulatTarget: Setting SCIENCE mode")
        @current_mode = 2
        
      when 'EMERGENCY_MODE'
        OpenC3::Logger.info("SimulatTarget: Setting EMERGENCY mode")
        @current_mode = 5
        
      else
        OpenC3::Logger.info("SimulatTarget: Received UNKNOWN command: #{name}")
      end
    end

    def read_temp1(packet)
      packet.write('TEMP1', packet.read('TEMP1') + (rand(20) - 10))
    end

    def read_temp2(packet)
      packet.write('TEMP2', packet.read('TEMP2') + (rand(20) - 10))
    end

    def read_temp3(packet)
      packet.write('TEMP3', packet.read('TEMP3') + (rand(20) - 10))
    end

    def read_temp4(packet)
      packet.write('TEMP4', packet.read('TEMP4') + (rand(20) - 10))
    end

    def write_heater(packet)
      if packet.read('HEATER') == 'ON'
        packet.write('TEMP1', packet.read('TEMP1') + 5)
        packet.write('TEMP2', packet.read('TEMP2') + 5)
        packet.write('TEMP3', packet.read('TEMP3') + 5) 
        packet.write('TEMP4', packet.read('TEMP4') + 5)
      end
    end

    def update_power_data(packet)
      # Simulate power consumption based on component states
      base_consumption = 15.0
      consumption = base_consumption
      
      consumption += 5.0 if packet.read('HEATER_POWER') == 1
      consumption += 10.0 if packet.read('RADIO_POWER') == 1
      consumption += 8.0 if packet.read('CAMERA_POWER') == 1
      
      # Add some randomness
      consumption += (rand(10) - 5)
      packet.write('POWER_CONSUMPTION', consumption)
      
      # Simulate battery voltage based on consumption
      base_voltage = 12.5
      voltage_drop = consumption * 0.05
      packet.write('BATTERY_VOLTAGE', base_voltage - voltage_drop + (rand(2) - 1))
      
      # Simulate current
      current = consumption / packet.read('BATTERY_VOLTAGE')
      packet.write('BATTERY_CURRENT', current + (rand(1) - 0.5))
      
      # Solar panel voltage varies
      packet.write('SOLAR_PANEL_VOLTAGE', 14.2 + (rand(4) - 2))
    end

    def update_environment_data(packet)
      # Simulate environmental changes based on current mode
      base_pressure = 101325.0
      case @current_mode
      when 0  # SAFE
        packet.write('PRESSURE', base_pressure + (rand(100) - 50))
      when 1  # NORMAL  
        packet.write('PRESSURE', base_pressure + (rand(200) - 100))
      when 2  # SCIENCE
        packet.write('PRESSURE', base_pressure + (rand(500) - 250))
      end
      
      # Humidity simulation
      packet.write('HUMIDITY', 45.0 + (rand(20) - 10))
      
      # Radiation varies with mode
      base_rad = 0.1
      rad_multiplier = case @current_mode
                      when 0 then 0.5  # SAFE mode - lower radiation
                      when 2 then 2.0  # SCIENCE mode - higher radiation
                      else 1.0
                      end
      packet.write('RADIATION', base_rad * rad_multiplier + (rand(0.2) - 0.1))
      
      # Magnetic field simulation
      packet.write('MAGNETIC_FIELD_X', 0.000025 + (rand(0.00002) - 0.00001))
      packet.write('MAGNETIC_FIELD_Y', 0.000030 + (rand(0.00002) - 0.00001))
      packet.write('MAGNETIC_FIELD_Z', 0.000045 + (rand(0.00002) - 0.00001))
      
      # Accelerometer simulation (mostly noise + gravity)
      packet.write('ACCELEROMETER_X', rand(0.2) - 0.1)
      packet.write('ACCELEROMETER_Y', rand(0.2) - 0.1)
      packet.write('ACCELEROMETER_Z', -9.81 + (rand(0.4) - 0.2))
    end
  end
end

# Check for command line arguments
if ARGV.length != 1
  puts "Usage: simulat_target.rb <configuration_file>"
  exit(1)
end

OpenC3::Logger.level = OpenC3::Logger::INFO
target = OpenC3::SimulatTarget.new(ARGV[0])
target.set_rates
OpenC3::Logger.info("SimulatTarget: Starting target simulation")
target.run