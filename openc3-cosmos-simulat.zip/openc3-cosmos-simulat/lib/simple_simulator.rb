require 'openc3/utilities/simulated_target'

module OpenC3
  class SimpleSimulator < SimulatedTarget
    def initialize(filename)
      super(filename)
      @target_name = 'SIMULAT3'
      
      # State variables that persist between calls
      @heater_state = 'OFF'
      @radio_state = 'ON'
      @camera_state = 'OFF'
      @current_mode = 'NORMAL'
      @collect_count = 0
      
      OpenC3::Logger.info("#{@target_name}: Simple simulator initialized")
    end

    def set_rates
      # Set packet rates (Hz)
      set_rate('STATUS', 1)
      set_rate('POWER', 1)
      set_rate('ENVIRONMENT', 1)
      
      initialize_telemetry_data
    end
    
    def initialize_telemetry_data
      # Initialize telemetry with current states
      if @tlm_packets && @tlm_packets[@target_name]
        
        # STATUS packet
        if @tlm_packets[@target_name]['STATUS']
          status_pkt = @tlm_packets[@target_name]['STATUS']
          status_pkt.write('TEMP1', 25.0)
          status_pkt.write('TEMP2', 30.0)
          status_pkt.write('TEMP3', 28.0)
          status_pkt.write('TEMP4', 22.0)
          status_pkt.write('HEATER', @heater_state)
          status_pkt.write('BATTERY', 85.5)
          status_pkt.write('COLLECTS', @collect_count)
          status_pkt.enable_method(:update_status_data)
        end
        
        # POWER packet
        if @tlm_packets[@target_name]['POWER']
          power_pkt = @tlm_packets[@target_name]['POWER']
          power_pkt.write('HEATER_POWER', @heater_state == 'ON' ? 1 : 0)
          power_pkt.write('RADIO_POWER', @radio_state == 'ON' ? 1 : 0)
          power_pkt.write('CAMERA_POWER', @camera_state == 'ON' ? 1 : 0)
          power_pkt.write('BATTERY_VOLTAGE', 12.5)
          power_pkt.write('BATTERY_CURRENT', 2.1)
          power_pkt.write('SOLAR_PANEL_VOLTAGE', 14.2)
          power_pkt.write('POWER_CONSUMPTION', 25.0)
          power_pkt.enable_method(:update_power_data)
        end
        
        # ENVIRONMENT packet  
        if @tlm_packets[@target_name]['ENVIRONMENT']
          env_pkt = @tlm_packets[@target_name]['ENVIRONMENT']
          env_pkt.write('PRESSURE', 101325.0)
          env_pkt.write('HUMIDITY', 45.0)
          env_pkt.write('RADIATION', 0.1)
          env_pkt.write('MAGNETIC_FIELD_X', 0.000025)
          env_pkt.write('MAGNETIC_FIELD_Y', 0.000030)
          env_pkt.write('MAGNETIC_FIELD_Z', 0.000045)
          env_pkt.write('ACCELEROMETER_X', 0.0)
          env_pkt.write('ACCELEROMETER_Y', 0.0)
          env_pkt.write('ACCELEROMETER_Z', -9.81)
          env_pkt.enable_method(:update_environment_data)
        end
      end
      
      OpenC3::Logger.info("#{@target_name}: Telemetry data initialized")
    end

    def write(packet)
      name = packet.packet_name.upcase
      OpenC3::Logger.info("#{@target_name}: *** COMMAND RECEIVED: #{name} ***")
      
      case name
      when 'COLLECT'
        @collect_count += 1
        update_telemetry_field('STATUS', 'COLLECTS', @collect_count)
        
      when 'CLEAR'
        @collect_count = 0
        update_telemetry_field('STATUS', 'COLLECTS', @collect_count)
        
      when 'HEATER_ON'
        @heater_state = 'ON'
        update_telemetry_field('STATUS', 'HEATER', @heater_state)
        update_telemetry_field('POWER', 'HEATER_POWER', 1)
        
      when 'HEATER_OFF'
        @heater_state = 'OFF'
        update_telemetry_field('STATUS', 'HEATER', @heater_state)
        update_telemetry_field('POWER', 'HEATER_POWER', 0)
        
      when 'RADIO_ON'
        @radio_state = 'ON'
        update_telemetry_field('POWER', 'RADIO_POWER', 1)
        
      when 'RADIO_OFF'
        @radio_state = 'OFF'
        update_telemetry_field('POWER', 'RADIO_POWER', 0)
        
      when 'CAMERA_ON'
        @camera_state = 'ON'
        update_telemetry_field('POWER', 'CAMERA_POWER', 1)
        
      when 'CAMERA_OFF'
        @camera_state = 'OFF'
        update_telemetry_field('POWER', 'CAMERA_POWER', 0)
        
      when 'SAFE_MODE'
        @current_mode = 'SAFE'
        
      when 'NORMAL_MODE'
        @current_mode = 'NORMAL'
        
      when 'SCIENCE_MODE'
        @current_mode = 'SCIENCE'
        
      when 'EMERGENCY_MODE'
        @current_mode = 'EMERGENCY'
        
      when 'SETPARAMS'
        value1 = packet.read('VALUE1')
        value2 = packet.read('VALUE2') 
        value3 = packet.read('VALUE3')
        update_telemetry_field('PARAMS', 'VALUE1', value1)
        update_telemetry_field('PARAMS', 'VALUE2', value2)
        update_telemetry_field('PARAMS', 'VALUE3', value3)
        
      else
        OpenC3::Logger.warn("#{@target_name}: Unknown command #{name}")
      end
      
      OpenC3::Logger.info("#{@target_name}: *** COMMAND #{name} PROCESSED SUCCESSFULLY ***")
    end
    
    private
    
    def update_telemetry_field(packet_name, field_name, value)
      return unless @tlm_packets && @tlm_packets[@target_name] && @tlm_packets[@target_name][packet_name]
      
      packet = @tlm_packets[@target_name][packet_name]
      packet.write(field_name, value)
      OpenC3::Logger.info("#{@target_name}: *** TELEMETRY UPDATED: #{packet_name}.#{field_name} = #{value} ***")
    end

    # Telemetry update methods called automatically by OpenC3
    def update_status_data(packet)
      # Add small temperature variations
      packet.write('TEMP1', packet.read('TEMP1') + (rand(4) - 2))
      packet.write('TEMP2', packet.read('TEMP2') + (rand(4) - 2))
      packet.write('TEMP3', packet.read('TEMP3') + (rand(4) - 2))
      packet.write('TEMP4', packet.read('TEMP4') + (rand(4) - 2))
      
      # Heater affects temperature
      if @heater_state == 'ON'
        packet.write('TEMP1', packet.read('TEMP1') + 2)
        packet.write('TEMP2', packet.read('TEMP2') + 2)
        packet.write('TEMP3', packet.read('TEMP3') + 2)
        packet.write('TEMP4', packet.read('TEMP4') + 2)
      end
      
      # Battery slowly drains
      battery = packet.read('BATTERY')
      battery -= 0.1 if battery > 10
      packet.write('BATTERY', battery)
    end

    def update_power_data(packet)
      base_consumption = 15.0
      consumption = base_consumption
      consumption += 5.0 if @heater_state == 'ON'
      consumption += 8.0 if @radio_state == 'ON'
      consumption += 6.0 if @camera_state == 'ON'
      
      packet.write('POWER_CONSUMPTION', consumption + rand(5))
      packet.write('BATTERY_VOLTAGE', 12.5 - (consumption * 0.02) + rand(1))
      packet.write('BATTERY_CURRENT', consumption / packet.read('BATTERY_VOLTAGE'))
      packet.write('SOLAR_PANEL_VOLTAGE', 14.2 + rand(2))
    end

    def update_environment_data(packet)
      base_pressure = 101325.0
      case @current_mode
      when 'SAFE'
        packet.write('PRESSURE', base_pressure + rand(50))
      when 'NORMAL'
        packet.write('PRESSURE', base_pressure + rand(100))
      when 'SCIENCE'
        packet.write('PRESSURE', base_pressure + rand(200))
      else
        packet.write('PRESSURE', base_pressure + rand(100))
      end
      
      packet.write('HUMIDITY', 45.0 + rand(20))
      packet.write('RADIATION', 0.1 + rand(0.2))
      
      packet.write('MAGNETIC_FIELD_X', 0.000025 + (rand(0.00001) - 0.000005))
      packet.write('MAGNETIC_FIELD_Y', 0.000030 + (rand(0.00001) - 0.000005))
      packet.write('MAGNETIC_FIELD_Z', 0.000045 + (rand(0.00001) - 0.000005))
      
      packet.write('ACCELEROMETER_X', rand(0.2) - 0.1)
      packet.write('ACCELEROMETER_Y', rand(0.2) - 0.1)
      packet.write('ACCELEROMETER_Z', -9.81 + rand(0.4) - 0.2)
    end
  end
end